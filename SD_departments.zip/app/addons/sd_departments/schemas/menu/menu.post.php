<?php 
$schema['central']['customers']['items']['sd_departments.departments'] = [
    'href' => 'departments.manage',
    'position' => 850,
];

return $schema;

?>